execute if score #seq_t rufu matches 1 run function rufu:seq/s25/t1
execute if score #seq_t rufu matches 30 run scoreboard players set #lock rufu 0
execute if score #seq_t rufu matches 30.. run scoreboard players set #seq rufu 0
