function rufu:show/prepare
