execute as @a at @s run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.5
execute as @a at @s run playsound minecraft:block.amethyst_block.chime master @s ~ ~ ~ 1 1.2
