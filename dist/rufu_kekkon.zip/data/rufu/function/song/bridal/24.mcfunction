execute as @a at @s run playsound minecraft:block.note_block.harp record @s ~ ~ ~ 0.9 0.8909
execute as @a at @s run playsound minecraft:block.note_block.bell record @s ~ ~ ~ 0.35 0.8909
